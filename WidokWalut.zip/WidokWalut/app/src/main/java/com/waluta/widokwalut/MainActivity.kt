package com.waluta.widokwalut

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    private lateinit var ListaWalut: TableLayout

    private lateinit var kol1: TextView
    private lateinit var kol2: TextView
    private lateinit var kol3: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ListaWalut=findViewById(R.id.ListaWalut)
        kol1=findViewById(R.id.kolumna1)
        kol2=findViewById(R.id.kolumna2)
        kol3=findViewById(R.id.kolumna3)

        for(i in 1..20) {
            var wiersz = TableRow(this)

            var k1 = TextView(this)
            var k2 = TextView(this)
            var k3 = TextView(this)

            k1.background = kol1.background
            k1.gravity = kol1.gravity
            k1.layoutParams = kol1.layoutParams

            k2.background = kol2.background
            k2.gravity = kol2.gravity
            k2.layoutParams = kol2.layoutParams

            k3.background = kol3.background
            k3.gravity = kol3.gravity
            k3.layoutParams = kol3.layoutParams

            k1.setText("USD")
            k2.setText("Dolar amerykański")
            k3.setText("4.200")

            wiersz.addView(k1)
            wiersz.addView(k2)
            wiersz.addView(k3)

            ListaWalut.addView(wiersz)
        }


    }
}